// -------------Navigation Bar ----------------------

const mobileMenu = document.getElementById('mobile-menu');
const menu = document.querySelector('.menu');

mobileMenu.addEventListener('click', () => {
    menu.classList.toggle('active'); // Toggle the active class to show/hide menu
});


// ------------------ Counting Numer ------------------------

let hasAnimated = false;

const countSection = document.getElementById('countSection');
const counts = document.querySelectorAll('.count');

const countUp = (element) => {
    const target = +element.getAttribute('data-target');
    let count = 0;
    const duration = 2000; // 2 seconds
    const increment = Math.floor(target / (duration / 100)); // Increment every 100ms

    const interval = setInterval(() => {
        count += increment;
        if (count >= target) {
            count = target;
            clearInterval(interval);
        }
        element.innerText = count;
    }, 100);
};

const animateCounts = () => {
    hasAnimated = true;

    counts.forEach(count => {
        countUp(count);
    });
};

const onScroll = () => {
    const sectionPos = countSection.getBoundingClientRect().top;
    const viewportHeight = window.innerHeight;

    if (sectionPos < viewportHeight && sectionPos > 0 && !hasAnimated) {
        animateCounts();
    } else if (sectionPos >= viewportHeight || sectionPos < 0) {
        hasAnimated = false; 
    }
};

window.addEventListener('scroll', onScroll);



// -------------------Scroll button ---------------------

// Get the button
const scrollToTopBtn = document.getElementById('scrollToTopBtn');

// Show or hide the button based on scroll position
window.onscroll = function() {
    if (document.body.scrollTop > 100 || document.documentElement.scrollTop > 100) {
        scrollToTopBtn.classList.add('show');
    } else {
        scrollToTopBtn.classList.remove('show');
    }
};

// Scroll to the top of the page when the button is clicked
scrollToTopBtn.onclick = function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth' 
    });
};
